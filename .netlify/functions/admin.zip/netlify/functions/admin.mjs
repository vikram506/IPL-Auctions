
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_store.js
import { getStore } from "@netlify/blobs";
import { readFileSync } from "node:fs";
var dataDir = new URL("../../data/", import.meta.url);
function loadJSON(name, fallback) {
  try {
    return JSON.parse(readFileSync(new URL(name, dataDir), "utf8"));
  } catch (e) {
    return fallback;
  }
}
var TEAMS = loadJSON("teams.json", []);
var PLAYERS = loadJSON("players.json", []);
function getPlayers() {
  return PLAYERS;
}
function playerByName(name) {
  return PLAYERS.find((p) => p.n === name) || null;
}
var OVERRIDES_KEY = "rating_overrides.json";
var CUSTOM_KEY = "custom_players.json";
async function getJSON(key) {
  const store = getStore({ name: "auction", consistency: "strong" });
  try {
    return await store.get(key, { type: "json" }) || null;
  } catch {
    return null;
  }
}
async function setJSON(key, obj) {
  const store = getStore({ name: "auction", consistency: "strong" });
  await store.setJSON(key, obj);
}
async function getOverrides() {
  const store = getStore({ name: "auction", consistency: "strong" });
  try {
    return await store.get(OVERRIDES_KEY, { type: "json" }) || {};
  } catch {
    return {};
  }
}
var overridesApplied = false;
async function ensureOverrides() {
  if (overridesApplied) return;
  const ov = await getOverrides();
  for (const p of PLAYERS) {
    const o = ov[p.n];
    if (o) {
      if (o.o != null) p.o = o.o;
      if (o.b != null) p.b = o.b;
      if (o.r != null) p.r = o.r;
      if (o.c != null) p.c = o.c;
    }
  }
  const custom = await getJSON(CUSTOM_KEY) || [];
  for (const cp of custom) {
    if (!playerByName(cp.n)) PLAYERS.push(cp);
  }
  overridesApplied = true;
}
async function saveOverride(name, fields) {
  const ov = await getOverrides();
  ov[name] = Object.assign(ov[name] || {}, fields);
  await setJSON(OVERRIDES_KEY, ov);
  const p = playerByName(name);
  if (p) Object.assign(p, fields);
  return p;
}
async function addCustomPlayer(player) {
  const custom = await getJSON(CUSTOM_KEY) || [];
  custom.push(player);
  await setJSON(CUSTOM_KEY, custom);
  getPlayers().push(player);
}
var ADMIN_USER = "VikramJain";
var ADMIN_PASS = "Vikram@12";
function checkAdmin(user, pw) {
  return user === ADMIN_USER && pw === ADMIN_PASS;
}

// netlify/functions/admin.js
var config = { path: "/api/admin" };
var admin_default = async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const body = await req.json().catch(() => ({}));
  if (!checkAdmin(body.user, body.pw)) return json({ error: "Wrong username or password" }, 401);
  await ensureOverrides();
  if (body.action === "list") {
    return json({ players: getPlayers() });
  }
  if (body.action === "update") {
    const name = body.name;
    const p = playerByName(name);
    if (!p) return json({ error: "Player not found" }, 404);
    const fields = {};
    if (body.o != null) fields.o = Math.max(40, Math.min(99, parseInt(body.o, 10)));
    if (body.b != null) fields.b = Math.max(20, Math.min(2e3, parseInt(body.b, 10)));
    await saveOverride(name, fields);
    return json({ ok: true, player: p });
  }
  if (body.action === "add") {
    const name = (body.name || "").trim();
    if (!name) return json({ error: "Name required" }, 400);
    if (playerByName(name)) return json({ error: "Player already exists" }, 409);
    const p = {
      n: name,
      c: (body.c || "IND").toUpperCase().slice(0, 3),
      r: ["BAT", "BOW", "AR", "WK"].includes(body.r) ? body.r : "BAT",
      o: Math.max(40, Math.min(99, parseInt(body.o, 10) || 75)),
      b: Math.max(20, Math.min(2e3, parseInt(body.b, 10) || 75)),
      t: ""
    };
    getPlayers().push(p);
    await addCustomPlayer(p);
    await saveOverride(name, { o: p.o, b: p.b, r: p.r, c: p.c });
    return json({ ok: true, player: p });
  }
  return json({ error: "Unknown action" }, 400);
};
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
  });
}
export {
  config,
  admin_default as default
};
