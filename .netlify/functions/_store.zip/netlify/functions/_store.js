var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var store_exports = {};
__export(store_exports, {
  ADMIN_PASS: () => ADMIN_PASS,
  ADMIN_USER: () => ADMIN_USER,
  RULES: () => RULES,
  TEAMS: () => TEAMS,
  addCustomPlayer: () => addCustomPlayer,
  checkAdmin: () => checkAdmin,
  deleteRoom: () => deleteRoom,
  ensureOverrides: () => ensureOverrides,
  fmtLakh: () => fmtLakh,
  getOverrides: () => getOverrides,
  getPlayers: () => getPlayers,
  getRoom: () => getRoom,
  makeCode: () => makeCode,
  makeToken: () => makeToken,
  maxBidFor: () => maxBidFor,
  nextBid: () => nextBid,
  overseasCount: () => overseasCount,
  playerByName: () => playerByName,
  playersForRoom: () => playersForRoom,
  publicRoom: () => publicRoom,
  saveOverride: () => saveOverride,
  saveRoom: () => saveRoom,
  squadSize: () => squadSize
});
module.exports = __toCommonJS(store_exports);
var import_blobs = require("@netlify/blobs");
var import_node_fs = require("node:fs");
const import_meta = {};
const dataDir = new URL("../../data/", import_meta.url);
function loadJSON(name, fallback) {
  try {
    return JSON.parse((0, import_node_fs.readFileSync)(new URL(name, dataDir), "utf8"));
  } catch (e) {
    return fallback;
  }
}
const TEAMS = loadJSON("teams.json", []);
let PLAYERS = loadJSON("players.json", []);
function getPlayers() {
  return PLAYERS;
}
function playerByName(name) {
  return PLAYERS.find((p) => p.n === name) || null;
}
const OVERRIDES_KEY = "rating_overrides.json";
const CUSTOM_KEY = "custom_players.json";
async function getJSON(key) {
  const store2 = (0, import_blobs.getStore)({ name: "auction", consistency: "strong" });
  try {
    return await store2.get(key, { type: "json" }) || null;
  } catch {
    return null;
  }
}
async function setJSON(key, obj) {
  const store2 = (0, import_blobs.getStore)({ name: "auction", consistency: "strong" });
  await store2.setJSON(key, obj);
}
async function getOverrides() {
  const store2 = (0, import_blobs.getStore)({ name: "auction", consistency: "strong" });
  try {
    return await store2.get(OVERRIDES_KEY, { type: "json" }) || {};
  } catch {
    return {};
  }
}
let overridesApplied = false;
async function ensureOverrides() {
  if (overridesApplied) return;
  const ov = await getOverrides();
  for (const p of PLAYERS) {
    const o = ov[p.n];
    if (o) {
      if (o.o != null) p.o = o.o;
      if (o.b != null) p.b = o.b;
      if (o.r != null) p.r = o.r;
      if (o.c != null) p.c = o.c;
    }
  }
  const custom = await getJSON(CUSTOM_KEY) || [];
  for (const cp of custom) {
    if (!playerByName(cp.n)) PLAYERS.push(cp);
  }
  overridesApplied = true;
}
async function saveOverride(name, fields) {
  const ov = await getOverrides();
  ov[name] = Object.assign(ov[name] || {}, fields);
  await setJSON(OVERRIDES_KEY, ov);
  const p = playerByName(name);
  if (p) Object.assign(p, fields);
  return p;
}
async function addCustomPlayer(player) {
  const custom = await getJSON(CUSTOM_KEY) || [];
  custom.push(player);
  await setJSON(CUSTOM_KEY, custom);
  getPlayers().push(player);
}
const ROOM_PREFIX = "room:";
function store() {
  return (0, import_blobs.getStore)({ name: "auction", consistency: "strong" });
}
async function getRoom(code) {
  return store().get(ROOM_PREFIX + code, { type: "json" });
}
async function saveRoom(room) {
  await store().setJSON(ROOM_PREFIX + room.code, room);
}
async function deleteRoom(code) {
  await store().delete(ROOM_PREFIX + code);
}
function makeCode() {
  const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let c = "";
  for (let i = 0; i < 6; i++) c += A[Math.floor(Math.random() * A.length)];
  return c;
}
function makeToken() {
  const A = "abcdefghijklmnopqrstuvwxyz0123456789";
  let t = "";
  for (let i = 0; i < 24; i++) t += A[Math.floor(Math.random() * A.length)];
  return t;
}
const RULES = {
  MEGA: { label: "Mega Auction", purse: 12e3, minSquad: 16, maxSquad: 25, maxOverseas: 8 },
  MINI: { label: "Mini Auction", purse: 4e3, minSquad: 16, maxSquad: 25, maxOverseas: 8 }
};
function nextBid(price) {
  if (price < 100) return price + 5;
  if (price < 200) return price + 10;
  if (price < 500) return price + 20;
  if (price < 1e3) return price + 40;
  return price + 80;
}
function fmtLakh(l) {
  if (l == null) return "\u2014";
  if (l >= 100) {
    const cr = l / 100;
    return "\u20B9" + (Number.isInteger(cr) ? cr : cr.toFixed(2)) + " Cr";
  }
  return "\u20B9" + l + " L";
}
function squadSize(t) {
  return t.squad.length;
}
function overseasCount(t) {
  let n = 0;
  for (const s of t.squad) {
    const p = playerByName(s.n);
    if (p && p.c !== "IND") n++;
  }
  return n;
}
function maxBidFor(t, rules, player) {
  const spotsLeft = rules.maxSquad - squadSize(t);
  if (spotsLeft <= 0) return 0;
  let cap = t.purse - (spotsLeft - 1) * 40;
  if (player && player.c !== "IND" && overseasCount(t) >= rules.maxOverseas) return 0;
  return Math.max(0, cap);
}
const ADMIN_USER = "VikramJain";
const ADMIN_PASS = "Vikram@12";
function checkAdmin(user, pw) {
  return user === ADMIN_USER && pw === ADMIN_PASS;
}
function publicRoom(room) {
  const cur = room.current;
  let curPub = null;
  if (cur) {
    const p = playerByName(cur.name);
    curPub = {
      name: cur.name,
      bid: cur.bid,
      leader: cur.leader,
      endsAt: cur.endsAt,
      base: p ? p.b : 20,
      overseas: p ? p.c !== "IND" : false
    };
    if (room.showRatings && p) {
      curPub.rating = p.o;
      curPub.role = p.r;
      curPub.country = p.c;
    }
  }
  return {
    code: room.code,
    mode: room.mode,
    rules: room.rules,
    phase: room.phase,
    // LOBBY | AUCTION | DONE
    paused: room.paused,
    showRatings: room.showRatings,
    bidSeconds: room.bidSeconds,
    hostTeam: room.hostTeam,
    order: room.order,
    teams: Object.fromEntries(room.order.map((id) => {
      const t = room.teams[id];
      return [id, {
        id,
        name: t.name,
        short: t.short,
        gradient: t.gradient,
        purse: t.purse,
        owner: t.owner,
        squad: t.squad
      }];
    })),
    current: curPub,
    log: (room.log || []).slice(0, 50),
    queueLeft: (room.queue || []).length + (room.unsold || []).length,
    done: room.phase === "DONE"
  };
}
function playersForRoom(room) {
  const list = getPlayers().map((p) => {
    if (room.showRatings) return { n: p.n, c: p.c, r: p.r, o: p.o, b: p.b };
    return { n: p.n, c: p.c, r: null, o: null, b: p.b };
  });
  return list;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ADMIN_PASS,
  ADMIN_USER,
  RULES,
  TEAMS,
  addCustomPlayer,
  checkAdmin,
  deleteRoom,
  ensureOverrides,
  fmtLakh,
  getOverrides,
  getPlayers,
  getRoom,
  makeCode,
  makeToken,
  maxBidFor,
  nextBid,
  overseasCount,
  playerByName,
  playersForRoom,
  publicRoom,
  saveOverride,
  saveRoom,
  squadSize
});
