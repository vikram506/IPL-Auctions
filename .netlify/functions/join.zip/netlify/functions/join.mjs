
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/join.js
import { getStore as getStore2 } from "@netlify/blobs";

// netlify/functions/_store.js
import { getStore } from "@netlify/blobs";
import { readFileSync } from "node:fs";
var dataDir = new URL("../../data/", import.meta.url);
function loadJSON(name, fallback) {
  try {
    return JSON.parse(readFileSync(new URL(name, dataDir), "utf8"));
  } catch (e) {
    return fallback;
  }
}
var TEAMS = loadJSON("teams.json", []);
var PLAYERS = loadJSON("players.json", []);

// netlify/functions/join.js
var config = { path: "/api/join" };
var join_default = async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const body = await req.json().catch(() => ({}));
  const code = (body.code || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  const team = body.team;
  const name = (body.name || "").trim().slice(0, 24);
  if (!code || !team || !name) return json({ error: "Enter code, name and pick a franchise" }, 400);
  if (!TEAMS.find((t2) => t2.id === team)) return json({ error: "Unknown franchise" }, 400);
  const store = getStore2({ name: "auction", consistency: "strong" });
  const room = await store.get("room:" + code, { type: "json" });
  if (!room) return json({ error: "Room not found" }, 404);
  if (room.phase !== "LOBBY") return json({ error: "Auction already started" }, 409);
  const t = room.teams[team];
  const claimedInRoom = t && t.owner && t.owner !== name;
  let claimedInBlob = false;
  try {
    const existing = await store.get("join:" + code + ":" + team, { type: "json" });
    if (existing && existing.name !== name && Date.now() - existing.at < 2e4) claimedInBlob = true;
  } catch (e) {
  }
  if (claimedInRoom || claimedInBlob) return json({ error: "That franchise was just taken \u2014 pick another" }, 409);
  await store.setJSON("join:" + code + ":" + team, { name, team, at: Date.now() });
  return json({ ok: true, team, token: "team:" + code + ":" + team });
};
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
  });
}
export {
  config,
  join_default as default
};
